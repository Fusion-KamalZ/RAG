# ui_components.py
import streamlit as st
from config import AVAILABLE_MODELS

def render_sidebar_config(current_api_key, current_selected_model):
    """Renders the API key and model selection in the sidebar."""
    st.sidebar.subheader("API Settings")
    api_key_input = st.sidebar.text_input(
        "Enter your Google AI API Key:",
        type="password",
        value=current_api_key or "",
        key="api_key_input_widget"
    )
    selected_model_input = st.sidebar.selectbox(
        "Select Gemini Chat Model:",
        options=AVAILABLE_MODELS,
        index=AVAILABLE_MODELS.index(current_selected_model) if current_selected_model in AVAILABLE_MODELS else 0,
        key="model_select_widget"
    )
    save_button_pressed = st.sidebar.button("Save Settings")
    return api_key_input, selected_model_input, save_button_pressed


def render_kb_creation_form_sidebar(): # MODIFIED: Only for initiating discovery
    """Renders the form in the sidebar to start link discovery."""
    st.sidebar.subheader("Add New Source (Multi-URL)")
    base_url_for_discovery = st.sidebar.text_input(
        "Enter Base URL for link discovery:", key="base_url_input_sidebar"
    )
    discover_links_button = st.sidebar.button(
        "Discover Links & Select", key="discover_links_button_sidebar"
    )
    # KB name input is removed from here, will be in the modal
    return base_url_for_discovery, discover_links_button


def render_link_discovery_modal(
    phase: str,
    discovered_links: list,
    selected_links_map: dict, # {link_url: True/False}
    kb_name_value: str,
    status_message: str = None,
    error_message: str = None
):
    """
    Renders the multi-step "modal" UI in the main application area.
    Returns:
        action (str): The action triggered by the user (e.g., 'confirm_links', 'create_kb').
        payload (dict): Data associated with the action (e.g., selected links, kb_name).
    """
    action = None
    payload = {}
    st.markdown("---") # Visual separator for the modal area

    with st.container(border=True): # Visually group the modal
        st.subheader("🌐 Add Knowledge Base from Web Pages")

        if status_message:
            st.info(status_message)
        if error_message:
            st.error(error_message)

        if phase == 'idle_or_discovering': # Initial state or when discovery is running
            st.info("Enter a Base URL in the sidebar and click 'Discover Links & Select'.")
            # Spinner will be shown in chabot_app.py during actual discovery

        elif phase == 'selecting_links':
            st.markdown("**Step 1: Select pages to include**")
            if not discovered_links:
                st.warning("No links were found for the provided Base URL. Try a different URL.")
                if st.button("Close", key="modal_sel_close_no_links"):
                    action = "close_modal"
                return action, payload

            col1, col2 = st.columns(2)
            if col1.button("Select All", key="modal_select_all"):
                action = "select_all"
            if col2.button("Deselect All", key="modal_deselect_all"):
                action = "deselect_all"
            
            current_selections = {}
            link_selection_container = st.container(height=300) # Scrollable
            with link_selection_container:
                for link in discovered_links:
                    is_selected = st.checkbox(
                        link,
                        value=selected_links_map.get(link, True), # Default to selected
                        key=f"modal_cb_link_{hash(link)}"
                    )
                    current_selections[link] = is_selected
            payload['selected_links_map'] = current_selections

            num_selected = sum(1 for v in current_selections.values() if v)
            if st.button(f"Next: Name KB ({num_selected} selected)", key="modal_confirm_links", type="primary", disabled=num_selected==0):
                action = "confirm_links_go_to_naming"
            if st.button("Cancel Discovery", key="modal_sel_cancel"):
                action = "close_modal"

        elif phase == 'naming_kb':
            st.markdown("**Step 2: Name your Knowledge Base**")
            payload['selected_links_map'] = selected_links_map # Carry over selections

            kb_name_input_val = st.text_input(
                "Enter a unique name:",
                value=kb_name_value,
                key="modal_kb_name_input"
            )
            payload['kb_name'] = kb_name_input_val.strip()

            col1, col2, col3 = st.columns([1,1,1])
            if col1.button("⬅️ Back to Select Links", key="modal_back_to_select"):
                action = "back_to_selecting_links"
            if col2.button("Create Knowledge Base", key="modal_create_kb_final", type="primary", disabled=not payload['kb_name']):
                action = "create_kb_from_modal"
            if col3.button("Cancel", key="modal_name_cancel"):
                action = "close_modal"

        elif phase == 'creating_kb':
            st.info(f"⚙️ Creating Knowledge Base '{kb_name_value}'... This might take a few moments. Please wait.")
            # Actual creation happens in chabot_app.py

        elif phase == 'finished_success':
            st.success(f"✅ Knowledge Base '{kb_name_value}' created successfully!")
            if st.button("Done", key="modal_finish_close", type="primary"):
                action = "close_modal"

        elif phase == 'finished_error':
            st.error(f"❌ Failed to create Knowledge Base '{kb_name_value}'. {status_message or 'Check logs.'}")
            col1, col2 = st.columns(2)
            if col1.button("⬅️ Try Naming Again", key="modal_finish_try_name_again"):
                action = "back_to_naming_kb" # Assumes links are still selected
            if col2.button("Close", key="modal_finish_close_error"):
                action = "close_modal"
        
        elif phase == 'discovery_failed':
            st.error(f"⚠️ Link discovery failed. {status_message or 'Please try a different URL or check logs.'}")
            if st.button("Close", key="modal_discovery_fail_close"):
                action = "close_modal"

    st.markdown("---") # Footer for the modal area
    return action, payload


def render_kb_selection_ui(vector_manager):
    """Renders checkboxes for selecting existing knowledge bases in the sidebar."""
    st.sidebar.divider()
    st.sidebar.subheader("Query Sources")
    st.sidebar.write("Select sources to query:")
    available_indexes = vector_manager.get_available_indexes()
    selected_kb_names = []
    if not available_indexes:
        st.sidebar.info("No knowledge bases created yet. Add one using the 'Add New Source' option.")
    else:
        for index_name in available_indexes:
            if st.sidebar.checkbox(index_name, key=f"sidebar_cb_query_{index_name}"):
                selected_kb_names.append(index_name)
    return selected_kb_names

def display_chat_messages():
    """Displays all messages from st.session_state.messages."""
    for message in st.session_state.messages:
        with st.chat_message(message["role"]):
            st.markdown(message["content"])