# crawler_script.py
import asyncio
import sys
import logging
from crawl4ai import AsyncWebCrawler # Make sure 'crawl4ai' is in requirements.txt

# Configure logging for the script itself
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
# No need for script_logger = logging.getLogger(__name__) if using basicConfig directly for script output

async def crawl_url(url: str):
    """Crawls the given URL and returns markdown content and any error message."""
    crawler = AsyncWebCrawler()
    markdown_content = None
    error_message = None
    try:
        logging.info(f"Starting crawl for: {url}")
        await crawler.start()
        # 'magic=True' is specific to crawl4ai, enabling its intelligent extraction
        result = await crawler.arun(url=url, magic=True)
        if result and result.markdown:
            markdown_content = result.markdown
            logging.info(f"Successfully crawled and extracted markdown from: {url}. Length: {len(markdown_content)}")
        elif result and not result.markdown:
            error_message = f"Crawler finished for {url} but returned no markdown content (result.markdown was empty)."
            logging.warning(error_message)
        else: # result itself is None or falsy
            error_message = f"Crawler finished for {url} but returned no result object."
            logging.warning(error_message)
    except Exception as e:
        error_message = f"An error occurred during crawling {url}: {str(e)}"
        logging.exception(f"Exception during crawl for {url}:") # Log the full traceback
    finally:
        await crawler.close()
        logging.info(f"Crawler closed for: {url}")
    return markdown_content, error_message

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python crawler_script.py <url>", file=sys.stderr)
        sys.exit(1)

    target_url = sys.argv[1]

    # Run the async function
    # In Python 3.7+, asyncio.run() is the standard way
    markdown, error = asyncio.run(crawl_url(target_url))

    if markdown:
        # Print the successful result (markdown) to standard output
        # This is crucial for the subprocess in the main app to capture it
        print(markdown)
        sys.exit(0) # Exit with success code
    else:
        # Print the error message to standard error
        # This is crucial for the subprocess in the main app to capture it
        print(f"Error crawling {target_url}: {error}", file=sys.stderr)
        sys.exit(1) # Exit with failure code