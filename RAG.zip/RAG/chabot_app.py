# chabot_app.py
import streamlit as st
import os
import logging
from dotenv import load_dotenv

# Local imports
from config import DEFAULT_MODEL, INDEX_DIR, DEFAULT_RETRIEVER_K, DEFAULT_RETRIEVAL_SCORE_THRESHOLD
from llm_services import get_embeddings_model, get_llm
from ui_components import (
    render_sidebar_config,
    render_kb_creation_form_sidebar, # Renamed/modified
    render_kb_selection_ui,
    display_chat_messages,
    render_link_discovery_modal # New
)
from kb_operations import create_new_kb, discover_links_from_url
from chat_processing import process_user_query
from vector_store_manager import VectorStoreManager

# --- Basic Setup ---
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
app_logger = logging.getLogger(__name__)
load_dotenv()
app_logger.info("Streamlit app started.")

st.set_page_config(page_title="Contextual RAG Chatbot", layout="wide")
st.title("🤖 Contextual RAG Chatbot")
st.caption("Ask questions based on selected knowledge bases, with conversation history.")

# --- Initialize Session State ---
if 'api_key' not in st.session_state:
    st.session_state.api_key = os.getenv("GOOGLE_API_KEY")
if 'selected_model' not in st.session_state:
    st.session_state.selected_model = DEFAULT_MODEL
if 'settings_saved' not in st.session_state:
    st.session_state.settings_saved = bool(st.session_state.api_key)
if 'messages' not in st.session_state:
    st.session_state.messages = []

# Retrieval settings
if 'retrieval_k' not in st.session_state:
    st.session_state.retrieval_k = DEFAULT_RETRIEVER_K
if 'retrieval_score_threshold' not in st.session_state:
    st.session_state.retrieval_score_threshold = DEFAULT_RETRIEVAL_SCORE_THRESHOLD

# States for the Multi-URL KB Creation Modal
if 'show_kb_modal' not in st.session_state:
    st.session_state.show_kb_modal = False
if 'kb_modal_phase' not in st.session_state:
    # Phases: idle_or_discovering, selecting_links, naming_kb, creating_kb, finished_success, finished_error, discovery_failed
    st.session_state.kb_modal_phase = 'idle_or_discovering'
if 'kb_modal_base_url' not in st.session_state: # URL being processed
    st.session_state.kb_modal_base_url = ""
if 'kb_modal_discovered_links' not in st.session_state:
    st.session_state.kb_modal_discovered_links = []
if 'kb_modal_selected_links_map' not in st.session_state: # {link_url: True/False}
    st.session_state.kb_modal_selected_links_map = {}
if 'kb_modal_name_input' not in st.session_state:
    st.session_state.kb_modal_name_input = ""
if 'kb_modal_status_message' not in st.session_state: # For general status/error messages within modal
    st.session_state.kb_modal_status_message = ""


# --- Sidebar UI ---
st.sidebar.title("⚙️ Configuration")
api_key_val, model_val, save_pressed = render_sidebar_config(
    st.session_state.api_key, st.session_state.selected_model
)

if save_pressed:
    if api_key_val:
        st.session_state.api_key = api_key_val
        st.session_state.selected_model = model_val
        st.session_state.settings_saved = True
        st.sidebar.success("Settings saved!")
        # Clear potentially initialized models if API key or model changed
        for key in ['llm', 'embeddings', 'vector_manager']:
            if key in st.session_state: del st.session_state[key]
        st.rerun()
    else:
        st.sidebar.error("API Key cannot be empty.")
        st.session_state.settings_saved = False
st.sidebar.divider()

# KB Creation Initiator in Sidebar
base_url_from_sidebar, discover_button_sidebar_pressed = render_kb_creation_form_sidebar()

if discover_button_sidebar_pressed:
    if base_url_from_sidebar:
        st.session_state.show_kb_modal = True
        st.session_state.kb_modal_phase = 'idle_or_discovering' # Will transition to 'discovering_active'
        st.session_state.kb_modal_base_url = base_url_from_sidebar
        # Reset other modal states for a new discovery
        st.session_state.kb_modal_discovered_links = []
        st.session_state.kb_modal_selected_links_map = {}
        st.session_state.kb_modal_name_input = ""
        st.session_state.kb_modal_status_message = ""
        st.rerun() # Show modal and trigger discovery phase
    else:
        st.sidebar.warning("Please enter a Base URL to discover links.")

# KB Selection for Chat (in Sidebar)
# This needs to be available regardless of the modal state for the chat functionality
if st.session_state.get("settings_saved") and st.session_state.get("api_key"):
    # Initialize vector_manager if not already (needed for render_kb_selection_ui)
    if 'vector_manager' not in st.session_state or st.session_state.vector_manager is None:
        try:
            if 'embeddings' not in st.session_state or st.session_state.embeddings is None:
                st.session_state.embeddings = get_embeddings_model(st.session_state.api_key)
            if st.session_state.embeddings:
                 st.session_state.vector_manager = VectorStoreManager(
                    index_base_dir=INDEX_DIR, embeddings_model=st.session_state.embeddings)
            else:
                app_logger.error("Cannot init vector_manager for sidebar KB selection: Embeddings missing.")
        except Exception as e_init_vm:
            app_logger.error(f"Error initializing vector_manager for sidebar KB selection: {e_init_vm}")
            # Don't halt, but KB selection might be empty.
    
    if 'vector_manager' in st.session_state and st.session_state.vector_manager:
        selected_kb_names_for_chat = render_kb_selection_ui(st.session_state.vector_manager)
    else:
        selected_kb_names_for_chat = []
        st.sidebar.caption("KB selection unavailable: Core components not ready.")
else:
    selected_kb_names_for_chat = []


# --- Main App Logic & Modal Handling ---
if not st.session_state.get("settings_saved") or not st.session_state.get("api_key"):
    st.info("👈 Please enter your Google AI API Key and select a model in the sidebar, then click 'Save Settings'.")
else:
    # Initialize core components (LLM, Embeddings, VectorManager)
    initialization_error_occurred = False
    try:
        if 'embeddings' not in st.session_state or st.session_state.embeddings is None:
            st.session_state.embeddings = get_embeddings_model(st.session_state.api_key)
        if 'llm' not in st.session_state or st.session_state.llm is None:
            st.session_state.llm = get_llm(st.session_state.api_key, st.session_state.selected_model)
        if 'vector_manager' not in st.session_state or st.session_state.vector_manager is None:
            if st.session_state.embeddings:
                st.session_state.vector_manager = VectorStoreManager(
                    index_base_dir=INDEX_DIR, embeddings_model=st.session_state.embeddings)
            else:
                app_logger.error("Cannot init vector_manager for main app: Embeddings missing.")
                initialization_error_occurred = True
        
        embeddings = st.session_state.embeddings
        llm = st.session_state.llm
        vector_manager = st.session_state.vector_manager

        if not (embeddings and llm and vector_manager):
             app_logger.error("One or more core components failed to initialize for main app.")
             initialization_error_occurred = True
             if not st.session_state.show_kb_modal: # Don't show this error if modal is also trying to init
                st.error("Core components failed to load. Please check API key and settings.")

    except Exception as e:
        app_logger.exception(f"Critical error during main component initialization: {e}")
        st.error(f"Failed to initialize core services: {e}. Check API key/model and retry.")
        initialization_error_occurred = True
        for key in ['llm', 'embeddings', 'vector_manager']: # Clear to allow retry
            if key in st.session_state: del st.session_state[key]

    # --- KB Creation Modal Logic (Main Area) ---
    if st.session_state.show_kb_modal and not initialization_error_occurred:
        modal_action = None
        modal_payload = {}

        # Handle active phases that require backend calls before rendering the UI
        if st.session_state.kb_modal_phase == 'idle_or_discovering' and st.session_state.kb_modal_base_url:
            # This is the trigger from sidebar to start discovery
            with st.spinner(f"Discovering links from {st.session_state.kb_modal_base_url}..."):
                discovered_list, error_msg = discover_links_from_url(st.session_state.kb_modal_base_url)
            
            if discovered_list is not None: # Script ran (could be empty list)
                st.session_state.kb_modal_discovered_links = discovered_list
                st.session_state.kb_modal_selected_links_map = {link: True for link in discovered_list}
                if not discovered_list:
                    st.session_state.kb_modal_status_message = error_msg or "No internal links were found on the page."
                    # No specific phase for "no links", selecting_links will handle empty list display
                st.session_state.kb_modal_phase = 'selecting_links'
            else: # Script hard-failed
                st.session_state.kb_modal_status_message = error_msg or "Link discovery script failed critically."
                st.session_state.kb_modal_phase = 'discovery_failed'
            st.rerun() # Re-render with new phase and data

        elif st.session_state.kb_modal_phase == 'creating_kb':
            # This phase is active, perform creation
            links_to_use_for_kb = [
                link for link, selected in st.session_state.kb_modal_selected_links_map.items() if selected
            ]
            if not links_to_use_for_kb:
                st.session_state.kb_modal_status_message = "No links were selected for KB creation."
                st.session_state.kb_modal_phase = 'finished_error' # Or back to 'selecting_links'
                st.rerun()
            elif not st.session_state.kb_modal_name_input:
                st.session_state.kb_modal_status_message = "KB Name is missing."
                st.session_state.kb_modal_phase = 'naming_kb' # Go back to naming
                st.rerun()
            else:
                with st.spinner(f"Creating KB '{st.session_state.kb_modal_name_input}'..."):
                    success = create_new_kb(
                        kb_name=st.session_state.kb_modal_name_input,
                        vector_manager=vector_manager, # Make sure this is initialized
                        selected_urls=links_to_use_for_kb,
                        source_base_url=st.session_state.kb_modal_base_url
                    )
                if success:
                    st.session_state.kb_modal_phase = 'finished_success'
                    st.session_state.kb_modal_status_message = f"KB '{st.session_state.kb_modal_name_input}' created."
                else:
                    st.session_state.kb_modal_phase = 'finished_error'
                    st.session_state.kb_modal_status_message = f"Failed to create KB '{st.session_state.kb_modal_name_input}'."
                st.rerun()
        
        # Render the modal UI based on the current phase (which might have been updated above)
        modal_action, modal_payload = render_link_discovery_modal(
            phase=st.session_state.kb_modal_phase,
            discovered_links=st.session_state.kb_modal_discovered_links,
            selected_links_map=st.session_state.kb_modal_selected_links_map,
            kb_name_value=st.session_state.kb_modal_name_input,
            status_message=st.session_state.kb_modal_status_message, # Pass status
            error_message=None # Specific error for modal, status_message can cover this too
        )
        st.session_state.kb_modal_status_message = "" # Clear status after displaying

        # Process actions from the modal UI
        if modal_action:
            if modal_action == "close_modal":
                st.session_state.show_kb_modal = False
                # Reset all modal states
                st.session_state.kb_modal_phase = 'idle_or_discovering'
                st.session_state.kb_modal_base_url = ""
                st.session_state.kb_modal_discovered_links = []
                st.session_state.kb_modal_selected_links_map = {}
                st.session_state.kb_modal_name_input = ""
                st.session_state.kb_modal_status_message = ""
            elif modal_action == "select_all":
                st.session_state.kb_modal_selected_links_map = {link: True for link in st.session_state.kb_modal_discovered_links}
            elif modal_action == "deselect_all":
                st.session_state.kb_modal_selected_links_map = {link: False for link in st.session_state.kb_modal_discovered_links}
            elif modal_action == "confirm_links_go_to_naming":
                st.session_state.kb_modal_selected_links_map = modal_payload.get('selected_links_map', {})
                num_sel = sum(1 for v in st.session_state.kb_modal_selected_links_map.values() if v)
                if num_sel > 0:
                    st.session_state.kb_modal_phase = 'naming_kb'
                else:
                    st.session_state.kb_modal_status_message = "Please select at least one link."
                    # Stays in 'selecting_links' phase, message will be shown
            elif modal_action == "back_to_selecting_links":
                st.session_state.kb_modal_name_input = modal_payload.get('kb_name', st.session_state.kb_modal_name_input) # Persist name
                st.session_state.kb_modal_phase = 'selecting_links'
            elif modal_action == "create_kb_from_modal":
                kb_name = modal_payload.get('kb_name', "").strip()
                if kb_name:
                    st.session_state.kb_modal_name_input = kb_name
                    st.session_state.kb_modal_phase = 'creating_kb' # This will trigger the backend call on next rerun
                else:
                    st.session_state.kb_modal_status_message = "Knowledge Base name cannot be empty."
                    # Stays in 'naming_kb' phase
            elif modal_action == "back_to_naming_kb":
                 st.session_state.kb_modal_phase = 'naming_kb'

            if modal_action: # If any modal action occurred, rerun to reflect changes
                st.rerun()

    # --- Chat Interface (Shown if modal is not active OR if core components loaded) ---
    if not st.session_state.show_kb_modal and not initialization_error_occurred and vector_manager and llm:
        st.markdown("---") 
        display_chat_messages()

        user_question = st.chat_input("Ask your question...")
        if user_question:
            # (Chat processing logic remains the same as your previous full version)
            st.session_state.messages.append({"role": "user", "content": user_question})
            with st.chat_message("user"): st.markdown(user_question)
            with st.chat_message("assistant"):
                msg_placeholder = st.empty()
                status_msg = "Thinking..."
                if selected_kb_names_for_chat: status_msg = f"Searching in: {', '.join(selected_kb_names_for_chat)}..."
                msg_placeholder.markdown(status_msg)
                
                processed_result = process_user_query(
                    user_question, selected_kb_names_for_chat, vector_manager, llm,
                    st.session_state.messages, st.session_state.retrieval_k,
                    st.session_state.retrieval_score_threshold
                )
                resp = processed_result.get("response")
                ctx = processed_result.get("context_used")
                err = processed_result.get("error")

                if err: st.warning(f"Note: {err}")
                if resp:
                    msg_placeholder.markdown(resp)
                    st.session_state.messages.append({"role": "assistant", "content": resp})
                else:
                    final_err = "Sorry, I couldn't generate a response." + (f" (Details: {err})" if err else "")
                    msg_placeholder.error(final_err)
                    st.session_state.messages.append({"role": "assistant", "content": final_err})
                if ctx:
                    with st.expander("Show Context Used"): st.markdown(ctx)
    elif initialization_error_occurred and not st.session_state.show_kb_modal :
        # This button is only shown if not in modal and init failed
        if st.button("Retry Initialization of Core Services"):
            for key in ['llm', 'embeddings', 'vector_manager']:
                if key in st.session_state: del st.session_state[key]
            st.rerun()

st.markdown("---")
st.caption("Contextual RAG Chatbot (Modal KB Creation)")