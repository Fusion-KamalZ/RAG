# config.py
import os

# Model Configuration
AVAILABLE_MODELS = [
    "gemini-1.5-flash",
    "gemini-1.5-pro",
]
DEFAULT_MODEL = AVAILABLE_MODELS[0]
EMBEDDING_MODEL_NAME = "models/embedding-001"

# Directory Configuration
INDEX_DIR = "faiss_indexes"

# Crawler Configuration
CRAWLER_SCRIPT_PATH = os.path.join(os.path.dirname(__file__), "crawler_script.py")
CRAWLER_TIMEOUT = 180 # seconds

# RAG Configuration
RAG_TEMPLATE_STR = """You are a helpful assistant answering questions based on the provided context and chat history.

Use the following pieces of retrieved context from documentation to answer the question.
Each piece of context is preceded by its source (e.g., "Source: KB_NAME").
Prioritize information from the context if it directly addresses the question.
Consider the ongoing conversation history for context.
If the context does not contain the answer or is not relevant to the question, rely on your general knowledge and the chat history to provide a helpful response.
Synthesize information if it comes from multiple sources or context/history. Keep the answer concise and relevant to the user's query.

Chat History:
{chat_history_str}

Retrieved Context:
{context}

Question:
{question}

Answer:"""
DEFAULT_RETRIEVER_K = 3
DEFAULT_RETRIEVAL_SCORE_THRESHOLD = 0.7 # Default similarity score threshold