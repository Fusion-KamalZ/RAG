# llm_services.py
# import streamlit as st # No longer needed if @st.cache_resource is removed
import logging
from langchain_google_genai import ChatGoogleGenerativeAI, GoogleGenerativeAIEmbeddings
from config import EMBEDDING_MODEL_NAME

logger = logging.getLogger(__name__)

# @st.cache_resource # REMOVE THIS
def get_embeddings_model(api_key: str):
    logger.info(f"Initializing Embeddings Model for session...")
    try:
        return GoogleGenerativeAIEmbeddings(model=EMBEDDING_MODEL_NAME, google_api_key=api_key)
    except Exception as e:
        # st.error(f"Failed to initialize Embeddings Model: {e}") # You might want to handle UI errors differently now
        logger.error(f"Embeddings initialization failed: {e}", exc_info=True)
        # Consider how to propagate this error to the UI if st.error is removed.
        # For now, let's assume the main app will catch it or the app won't proceed.
        raise # Or return None and let the caller handle it
    # return None # This was for when st.error was used

# @st.cache_resource # REMOVE THIS
def get_llm(api_key: str, model_name: str):
    logger.info(f"Initializing LLM '{model_name}' for session...")
    try:
        return ChatGoogleGenerativeAI(model=model_name, google_api_key=api_key, temperature=0.7, convert_system_message_to_human=True)
    except Exception as e:
        # st.error(f"Failed to initialize LLM '{model_name}': {e}") # Handle UI error
        logger.error(f"LLM initialization failed for model {model_name}: {e}", exc_info=True)
        raise # Or return None
    # return None