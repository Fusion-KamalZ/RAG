# utils.py
from langchain.schema import Document

def format_docs(docs: list) -> str:
    """
    Combines page content of retrieved documents.
    If documents have metadata with a 'source_kb_name', it will be prepended.
    """
    if not docs:
        return "No relevant context found."

    formatted_strings = []
    for doc in docs:
        content = ""
        source_info = ""
        if isinstance(doc, Document):
            content = doc.page_content
            if doc.metadata and "source_kb_name" in doc.metadata:
                source_info = f"Source: {doc.metadata['source_kb_name']}\n"
            elif doc.metadata and "source" in doc.metadata: # Fallback if 'source' is used
                source_info = f"Source: {doc.metadata['source']}\n"

        elif hasattr(doc, 'page_content'): # For objects that look like Documents
            content = doc.page_content
            if hasattr(doc, 'metadata') and doc.metadata and "source_kb_name" in doc.metadata:
                source_info = f"Source: {doc.metadata['source_kb_name']}\n"
            elif hasattr(doc, 'metadata') and doc.metadata and "source" in doc.metadata:
                source_info = f"Source: {doc.metadata['source']}\n"
        else:
            content = str(doc) # Fallback for plain strings or other objects

        formatted_strings.append(f"{source_info}{content}")

    return "\n\n---\n\n".join(formatted_strings)