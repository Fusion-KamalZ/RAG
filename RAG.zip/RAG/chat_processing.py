# chat_processing.py
import logging
from langchain.prompts import ChatPromptTemplate
from langchain.schema.runnable import RunnablePassthrough
from langchain.schema.output_parser import StrOutputParser
from langchain.schema import AIMessage, HumanMessage, Document
from utils import format_docs # Expects format_docs to handle source attribution
from config import RAG_TEMPLATE_STR, DEFAULT_RETRIEVER_K, DEFAULT_RETRIEVAL_SCORE_THRESHOLD

logger = logging.getLogger(__name__)

def _prepare_messages_for_llm(history_messages, current_user_question):
    messages_for_llm = []
    for msg in history_messages:
        if msg["role"] == "user":
            messages_for_llm.append(HumanMessage(content=msg["content"]))
        elif msg["role"] == "assistant":
            messages_for_llm.append(AIMessage(content=msg["content"]))
    messages_for_llm.append(HumanMessage(content=current_user_question))
    return messages_for_llm

def _invoke_direct_llm(llm, messages):
    logger.debug(f"Messages sent to LLM (direct): {[m.pretty_repr() for m in messages]}")
    try:
        ai_response = llm.invoke(messages)
        return ai_response.content if hasattr(ai_response, 'content') else str(ai_response)
    except Exception as e:
        logger.exception("Error during direct LLM invocation")
        raise # Re-raise to be caught by the main processing logic

def process_user_query(user_question: str,
                       selected_kb_names: list,
                       vector_manager,
                       llm,
                       chat_history: list, # This is st.session_state.messages
                       retrieval_k: int = DEFAULT_RETRIEVER_K,
                       retrieval_score_threshold: float = DEFAULT_RETRIEVAL_SCORE_THRESHOLD):
    assistant_response_content = "Sorry, I encountered an issue and could not generate a response."
    status_message_for_ui = "Processing your query..."
    retrieved_context_for_ui = None
    error_message_for_ui = None

    history_for_llm = chat_history[:-1]

    if not selected_kb_names:
        logger.info("No KBs selected. Using direct LLM call.")
        status_message_for_ui = "Thinking... 🤔 (using general knowledge)"
        try:
            messages = _prepare_messages_for_llm(history_for_llm, user_question)
            assistant_response_content = _invoke_direct_llm(llm, messages)
            logger.info("Direct LLM call successful.")
        except Exception as e:
            logger.exception("Direct LLM execution error (no KBs).")
            error_message_for_ui = f"Error using general knowledge: {e}"
        
        return {
            "response": assistant_response_content,
            "status_message": status_message_for_ui,
            "context_used": None,
            "error": error_message_for_ui
        }

    # RAG Path
    initial_status_msg = f"Searching in: {', '.join(selected_kb_names)}... 🤔"
    status_message_for_ui = initial_status_msg
    all_retrieved_docs_with_source = [] # Store tuples of (doc, source_name)
    retrieval_errors_encountered = False
    specific_retrieval_error_messages = []

    logger.info(f"Starting retrieval for: '{user_question}', k={retrieval_k}, threshold={retrieval_score_threshold}")
    for kb_name in selected_kb_names:
        try:
            retriever = vector_manager.get_retriever(
                kb_name,
                k=retrieval_k,
                score_threshold=retrieval_score_threshold
            )
            if retriever:
                # Langchain retrievers return Document objects.
                # Their metadata should ideally include 'source_kb_name' if set during indexing.
                docs = retriever.invoke(user_question)
                logger.info(f"Retrieved {len(docs)} docs from KB: {kb_name}")
                for doc in docs:
                    # Ensure source_kb_name is in metadata, if not already there from indexing
                    if 'source_kb_name' not in doc.metadata:
                        doc.metadata['source_kb_name'] = kb_name
                all_retrieved_docs_with_source.extend(docs) # Add all docs directly
            else:
                msg = f"Could not get retriever for '{kb_name}'."
                logger.error(msg)
                specific_retrieval_error_messages.append(msg)
                retrieval_errors_encountered = True
        except Exception as e:
            msg = f"Error retrieving from '{kb_name}': {e}"
            logger.exception(msg)
            specific_retrieval_error_messages.append(msg)
            retrieval_errors_encountered = True
    
    if specific_retrieval_error_messages:
        error_message_for_ui = "Retrieval issues: " + "; ".join(specific_retrieval_error_messages)

    if all_retrieved_docs_with_source:
        status_message_for_ui = "Found relevant documents. Generating answer..."
        logger.info(f"Generating answer using {len(all_retrieved_docs_with_source)} retrieved docs.")
        
        # format_docs now expects documents that might have metadata['source_kb_name']
        formatted_context = format_docs(all_retrieved_docs_with_source)
        retrieved_context_for_ui = formatted_context

        history_str = "\n".join([f"{msg['role']}: {msg['content']}" for msg in history_for_llm])
        
        rag_prompt_template = ChatPromptTemplate.from_template(RAG_TEMPLATE_STR)
        chain = (
            {
                "context": lambda x: formatted_context,
                "chat_history_str": lambda x: history_str,
                "question": RunnablePassthrough()
            }
            | rag_prompt_template
            | llm
            | StrOutputParser()
        )
        try:
            assistant_response_content = chain.invoke(user_question)
            logger.info("RAG chain invocation successful.")
        except Exception as e:
            logger.exception("RAG chain/LLM execution error.")
            error_message_for_ui = (error_message_for_ui + "; " if error_message_for_ui else "") + f"Error generating RAG answer: {e}"
    
    elif not retrieval_errors_encountered: # No docs found, no retrieval errors
        status_message_for_ui = "No specific info in selected documents. Trying general knowledge..."
        logger.warning(f"No documents retrieved for: '{user_question}'. Attempting direct LLM call.")
        try:
            messages = _prepare_messages_for_llm(history_for_llm, user_question)
            assistant_response_content = _invoke_direct_llm(llm, messages)
        except Exception as e:
            error_message_for_ui = (error_message_for_ui + "; " if error_message_for_ui else "") + f"Error using general knowledge (fallback): {e}"
    
    else: # Retrieval errors occurred, and no/few docs
        status_message_for_ui = "Issues with document sources. Trying general knowledge..."
        logger.error("Retrieval had errors. Attempting direct LLM call as fallback.")
        try:
            messages = _prepare_messages_for_llm(history_for_llm, user_question)
            assistant_response_content = _invoke_direct_llm(llm, messages)
        except Exception as e:
            error_message_for_ui = (error_message_for_ui + "; " if error_message_for_ui else "") + f"Error using general knowledge (error fallback): {e}"

    return {
        "response": assistant_response_content,
        "status_message": status_message_for_ui,
        "context_used": retrieved_context_for_ui,
        "error": error_message_for_ui
    }