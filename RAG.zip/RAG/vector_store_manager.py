# vector_store_manager.py
import os
import shutil
import logging
from langchain_community.vectorstores import FAISS
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.schema import Document

logger = logging.getLogger(__name__)

class VectorStoreManager:
    def __init__(self, index_base_dir: str, embeddings_model):
        logger.info(f"Initializing VectorStoreManager for directory: {index_base_dir}")
        self.index_base_dir = index_base_dir
        self.embeddings = embeddings_model
        self._loaded_stores = {}
        if not os.path.exists(self.index_base_dir):
            try:
                os.makedirs(self.index_base_dir)
                logger.info(f"Created base index directory: {self.index_base_dir}")
            except OSError as e:
                logger.error(f"Failed to create base index directory {self.index_base_dir}: {e}")
                raise

    def _create_and_save_index(self, index_name: str, source_content: str, base_metadata: dict = None):
        folder_path = os.path.join(self.index_base_dir, index_name)
        logger.info(f"Starting index creation process for: {index_name} in {folder_path}")

        if not source_content:
            logger.error(f"Source content for {index_name} is empty. Cannot create index.")
            return None

        if not os.path.exists(folder_path):
            try:
                os.makedirs(folder_path)
                logger.info(f"Created folder for index: {folder_path}")
            except OSError as e:
                logger.error(f"Failed to create folder {folder_path} for index {index_name}: {e}")
                return None
        
        vectorstore = None # Define vectorstore here to check in finally
        try:
            logger.info(f"[{index_name}] Preparing documents with metadata...")
            
            # Ensure 'source_kb_name' is always part of the chunk metadata
            # It will be merged with any other base_metadata provided
            final_chunk_metadata = {"source_kb_name": index_name}
            if base_metadata:
                final_chunk_metadata.update(base_metadata) # Merge provided KB-level metadata

            # Create a single document with all content and the final merged metadata
            initial_doc = Document(page_content=source_content, metadata=final_chunk_metadata)

            logger.info(f"[{index_name}] Initializing text splitter...")
            text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=200)

            logger.info(f"[{index_name}] Splitting document...")
            split_docs = text_splitter.split_documents([initial_doc]) # Pass as a list
            logger.info(f"[{index_name}] Split into {len(split_docs)} chunks.")

            if not split_docs:
                logger.error(f"[{index_name}] Failed to split documents (0 chunks). Index not created.")
                if os.path.exists(folder_path) and not os.listdir(folder_path):
                    shutil.rmtree(folder_path)
                    logger.info(f"[{index_name}] Removed empty folder due to no chunks: {folder_path}")
                return None

            logger.info(f"[{index_name}] Starting FAISS.from_documents (embedding documents)...")
            vectorstore = FAISS.from_documents(split_docs, self.embeddings)
            logger.info(f"[{index_name}] FAISS.from_documents completed successfully.")

            logger.info(f"[{index_name}] Saving FAISS index to local disk at {folder_path}...")
            vectorstore.save_local(folder_path)
            logger.info(f"[{index_name}] Index saved successfully.")
            return vectorstore
        except Exception as e:
            logger.exception(f"[{index_name}] Error during index creation/saving: {e}")
            return None
        finally:
            if vectorstore is None and os.path.exists(folder_path):
                if not os.path.exists(os.path.join(folder_path, "index.faiss")):
                    logger.warning(f"[{index_name}] Attempting to remove incomplete folder due to error: {folder_path}")
                    try:
                        shutil.rmtree(folder_path)
                    except OSError as rm_err:
                        logger.error(f"[{index_name}] Failed to remove folder {folder_path} after creation error: {rm_err}")


    def load_index(self, index_name: str):
        if index_name in self._loaded_stores:
            logger.debug(f"Returning cached index: {index_name}")
            return self._loaded_stores[index_name]

        folder_path = os.path.join(self.index_base_dir, index_name)
        index_file_path = os.path.join(folder_path, "index.faiss")

        if os.path.exists(folder_path) and os.path.exists(index_file_path):
            try:
                logger.info(f"Loading existing index from disk: {index_name} at {folder_path}")
                vectorstore = FAISS.load_local(folder_path, self.embeddings, allow_dangerous_deserialization=True)
                self._loaded_stores[index_name] = vectorstore
                logger.info(f"Index '{index_name}' loaded successfully and cached.")
                return vectorstore
            except Exception as e:
                logger.exception(f"Error loading index {index_name} from {folder_path}: {e}")
                return None
        else:
            logger.warning(f"Index '{index_name}' not found at {folder_path} (or index.faiss missing).")
            return None

    def create_new_knowledge_base(self, index_name: str, source_content: str, source_metadata: dict = None):
        logger.info(f"Request received to create new knowledge base: {index_name}")
        folder_path = os.path.join(self.index_base_dir, index_name)
        if os.path.exists(folder_path) and os.path.exists(os.path.join(folder_path, "index.faiss")):
            logger.warning(f"Index '{index_name}' already exists and appears valid at {folder_path}. Creation aborted.")
            return None # Or perhaps load and return the existing one if that's desired behavior

        # The `source_metadata` passed here will be combined with `{"source_kb_name": index_name}`
        # inside `_create_and_save_index` due to the modification.
        # Alternatively, the merging can happen here before calling _create_and_save_index,
        # but the current modification places the responsibility in _create_and_save_index.
        
        # For clarity, if `_create_and_save_index` handles the merge (as per the modification),
        # we just pass `source_metadata` along.
        # If we wanted to be explicit about what `_create_and_save_index` receives:
        # prepared_metadata = {"source_kb_name": index_name} # Always include this
        # if source_metadata:
        #     prepared_metadata.update(source_metadata)
        # vectorstore = self._create_and_save_index(index_name, source_content, base_metadata=prepared_metadata)
        #
        # However, with the implemented change in _create_and_save_index, just passing source_metadata is fine,
        # as _create_and_save_index will ensure source_kb_name is there and merge.

        logger.info(f"Calling internal _create_and_save_index for: {index_name} with provided source_metadata.")
        vectorstore = self._create_and_save_index(index_name, source_content, base_metadata=source_metadata)

        if vectorstore:
            self._loaded_stores[index_name] = vectorstore
            logger.info(f"Successfully created and cached knowledge base: {index_name}")
        else:
            logger.error(f"Failed to create knowledge base: {index_name}")
        return vectorstore

    def get_retriever(self, index_name: str, k: int = 3, score_threshold: float = None):
        logger.debug(f"Requesting retriever for index: {index_name} with k={k}, threshold={score_threshold}")
        vectorstore = self.load_index(index_name)
        if vectorstore:
            search_kwargs = {'k': k}
            if score_threshold is not None:
                # For FAISS with Langchain, to use score threshold, search_type needs to be specified
                return vectorstore.as_retriever(
                    search_type="similarity_score_threshold",
                    search_kwargs={'k': k, 'score_threshold': score_threshold}
                )
            else:
                return vectorstore.as_retriever(search_kwargs={'k': k})
        else:
            logger.error(f"Could not get vector store for index '{index_name}' to create retriever.")
            return None

    def get_available_indexes(self):
        logger.debug(f"Checking for available indexes in: {self.index_base_dir}")
        if not os.path.exists(self.index_base_dir):
            return []
        try:
            indexes = sorted([
                d for d in os.listdir(self.index_base_dir)
                if os.path.isdir(os.path.join(self.index_base_dir, d)) and \
                   os.path.exists(os.path.join(self.index_base_dir, d, "index.faiss"))
            ])
            return indexes
        except Exception as e:
            logger.error(f"Error listing available indexes in {self.index_base_dir}: {e}")
            return []