# File: link_extractor_script.py
import asyncio
import sys
from urllib.parse import urljoin, urlparse # For ensuring absolute URLs
from crawl4ai import AsyncWebCrawler, CacheMode # BrowserConfig not used in this simplified version

async def extract_links_from_page(target_url: str):
    """
    Crawls a single page and prints its internal absolute links, one per line.
    Any errors from crawl4ai will go to stderr.
    """
    # Try to make crawl4ai quiet. If it still prints, we may have issues.
    crawler = AsyncWebCrawler(silent=True)
    # Note: BrowserConfig (headless=False) from your snippet is not used here for simplicity in a script.
    # crawl4ai defaults to headless=True, which is typical for scripts.
    # If headless=False is strictly needed, it can be added back.

    try:
        await crawler.start()
        result = await crawler.arun(
            url=target_url,
            magic=False,  # We only need links, not full markdown processing here
            extract_links=True,
            exclude_external_links=True, # Focus on internal links
            cache_mode=CacheMode.BYPASS, # Or use caching as needed
            # scan_full_page=True, # From your snippet, keep if needed
            # scroll_delay=0.5,    # From your snippet, keep if needed
        )

        if result and result.links and "internal" in result.links:
            base_parsed_url = urlparse(target_url)
            unique_absolute_links = set()
            for link_info in result.links["internal"]:
                href = link_info.get("href")
                if href:
                    absolute_link = urljoin(target_url, href) # Make absolute
                    # Further check if it's truly on the same domain (optional, good practice)
                    parsed_link = urlparse(absolute_link)
                    if parsed_link.netloc == base_parsed_url.netloc:
                        unique_absolute_links.add(absolute_link)
            
            for link_url in sorted(list(unique_absolute_links)): # Print sorted unique links
                print(link_url) # This goes to stdout

    except Exception as e:
        # Errors from the crawler will likely go to stderr via crawl4ai's logging
        # or be caught here and printed to stderr.
        print(f"Error during link extraction for {target_url}: {e}", file=sys.stderr)
    finally:
        if crawler: # Check if crawler was initialized
            await crawler.close()

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python link_extractor_script.py <url_to_extract_links_from>", file=sys.stderr)
        sys.exit(1)

    url_to_scan = sys.argv[1]
    asyncio.run(extract_links_from_page(url_to_scan))
    # The script will exit with 0 if it completes, or non-zero if an unhandled exception occurs.
    # The parent process will read stdout for the links.