# kb_operations.py
import streamlit as st # Make sure Streamlit is imported if you use its components directly
import os
import sys
import subprocess
import logging
import re
# JSON is not needed here anymore for discover_links_from_url if output is line-by-line

from vector_store_manager import VectorStoreManager
from config import CRAWLER_SCRIPT_PATH, CRAWLER_TIMEOUT

# Define path for the new link extractor script
LINK_EXTRACTOR_SCRIPT_PATH = os.path.join(os.path.dirname(__file__), "link_extractor_script.py")
LINK_EXTRACTOR_TIMEOUT = 180 # Can be longer if deep crawling is implemented later

logger = logging.getLogger(__name__) # Ensure logger is configured elsewhere or here

def validate_kb_name(name: str) -> bool:
    return all(c.isalnum() or c in ('_', '-') for c in name) and name not in ('.', '..')

def basic_markdown_clean(markdown_text: str) -> str:
    if not markdown_text:
        return ""
    cleaned_text = re.sub(r'\n{3,}', '\n\n', markdown_text)
    return cleaned_text.strip()

def discover_links_from_url(base_url: str): # UPDATED
    """
    Calls the link_extractor_script.py to get internal links from a base URL.
    Expects link_extractor_script.py to print one URL per line to stdout.
    Returns a tuple: (list_of_links or None, error_message_string or None)
    """
    logger.info(f"Attempting to discover links from base URL: {base_url}")
    if not base_url:
        # This message will be handled by chabot_app.py or can be returned
        # st.sidebar.warning("Please enter a Base URL for discovery.") # Avoid direct st calls here
        logger.warning("discover_links_from_url called with empty base_url.")
        return None, "Base URL cannot be empty."

    links = []
    error_message_str = None
    
    # Optional: If you want progress in the sidebar directly from here,
    # you'd need to pass `st` or use a callback. Simpler to handle spinner in chabot_app.py.
    # progress_bar = st.sidebar.progress(0, text="Discovering links...")

    try:
        process_env = os.environ.copy()
        process_env["PYTHONIOENCODING"] = "utf-8" # Good practice

        if not os.path.exists(LINK_EXTRACTOR_SCRIPT_PATH):
            logger.error(f"link_extractor_script.py not found at {LINK_EXTRACTOR_SCRIPT_PATH}")
            return None, f"Internal error: Link extractor script not found."

        logger.info(f"Executing link extractor script: {sys.executable} {LINK_EXTRACTOR_SCRIPT_PATH} {base_url}")
        process = subprocess.run(
            [sys.executable, LINK_EXTRACTOR_SCRIPT_PATH, base_url],
            capture_output=True, text=True, encoding='utf-8',
            check=False, # We will check returncode manually
            timeout=LINK_EXTRACTOR_TIMEOUT, env=process_env
        )
        # if progress_bar: progress_bar.progress(50, text="Link extractor script finished. Processing output...")

        if process.returncode == 0: # Script exited successfully
            stdout_lines = process.stdout.strip().splitlines()
            links = [line.strip() for line in stdout_lines if line.strip()] # Clean up
            
            if not links:
                error_message_str = f"No internal links were found at {base_url} by the discovery script."
                logger.info(error_message_str)
            else:
                logger.info(f"Successfully discovered {len(links)} links from {base_url}.")
            
            # Log any stderr output from the script even on success, as it might contain warnings
            if process.stderr.strip():
                logger.warning(f"Link extractor script (exit 0) stderr for {base_url}: {process.stderr.strip()[:500]}")
        
        else: # Non-zero return code from script, indicates an error in the script itself
            err_details = process.stderr.strip() if process.stderr else "No stderr output."
            error_message_str = f"Link discovery script failed for {base_url}. Error: {err_details[:500]}"
            logger.error(f"Link extractor script failed. RC: {process.returncode}. Full Stderr: {process.stderr.strip()}")
            return None, error_message_str # Hard failure, return None for links

        # if progress_bar: progress_bar.progress(100, text="Link discovery processing complete.")

    except subprocess.TimeoutExpired:
        error_message_str = f"Link discovery script timed out for {base_url} after {LINK_EXTRACTOR_TIMEOUT} seconds."
        logger.error(error_message_str)
        # if progress_bar: progress_bar.progress(100, text="Link discovery timed out.")
        return None, error_message_str # Hard failure
    except FileNotFoundError as e: # Should be caught by the os.path.exists check earlier
        error_message_str = f"Critical error: Link extractor script file not found at {LINK_EXTRACTOR_SCRIPT_PATH}. Details: {e}"
        logger.error(error_message_str)
        # if progress_bar: progress_bar.progress(100, text="Script file not found.")
        return None, error_message_str # Hard failure
    except Exception as e:
        error_message_str = f"An unexpected error occurred during link discovery: {e}"
        logger.exception(f"Unexpected link discovery error for {base_url}:") # Log full traceback
        # if progress_bar: progress_bar.progress(100, text="Unexpected error during discovery.")
        return None, error_message_str # Hard failure
    
    # If we reach here, the script ran.
    # `links` is a list (possibly empty).
    # `error_message_str` is None if links were found, or "No internal links..." if script ran but found none.
    return links, error_message_str


def create_new_kb(
    kb_name: str,
    vector_manager: VectorStoreManager,
    selected_urls: list = None,
    single_url_for_kb: str = None, # Kept for potential direct single URL KB creation
    source_base_url: str = None
):
    logger.info(f"Attempting to create KB: {kb_name} with {len(selected_urls or [])} selected URLs.")
    if not kb_name:
        # This kind of UI feedback is better handled in chabot_app.py
        # st.sidebar.warning("Please enter a unique name for the KB.")
        logger.warning("KB creation attempted with no name.")
        return False # Or raise ValueError("KB name cannot be empty")

    if not validate_kb_name(kb_name):
        logger.warning(f"Invalid KB name attempt: {kb_name}")
        # st.sidebar.error("Invalid KB name. Use letters, numbers, underscores, hyphens only.")
        return False # Or raise ValueError("Invalid KB name")

    if kb_name in vector_manager.get_available_indexes():
        logger.warning(f"Attempt to create KB '{kb_name}' which already exists.")
        # st.sidebar.error(f"Knowledge base '{kb_name}' already exists.")
        return False # Or raise FileExistsError("KB already exists")

    if not selected_urls and not single_url_for_kb:
        logger.warning("KB creation attempted with no URLs.")
        # st.sidebar.warning("No URLs provided to create the knowledge base.")
        return False

    aggregated_markdown_content = ""
    crawl_errors = []
    successful_crawls = 0

    urls_to_process = []
    if selected_urls: # Prioritize selected_urls if provided for multi-URL KB
        urls_to_process.extend(selected_urls)
    elif single_url_for_kb: # Fallback for single URL
        urls_to_process.append(single_url_for_kb)
    
    # UI for progress should be managed in chabot_app.py using st.spinner or st.status
    # For now, logging will track progress.
    # with st.sidebar.expander(f"Creating KB '{kb_name}' from {len(urls_to_process)} URL(s)...", expanded=True):
    #    overall_progress = st.progress(0, text=f"Starting KB creation for '{kb_name}'")
        
    for i, url_to_crawl in enumerate(urls_to_process):
        logger.info(f"[{kb_name}] Crawling URL {i+1}/{len(urls_to_process)}: {url_to_crawl}")
        # st.info(f"[{kb_name}] Crawling URL {i+1}/{len(urls_to_process)}: {url_to_crawl}") # UI in chabot_app.py
        markdown_content_single = None
        try:
            process_env = os.environ.copy()
            process_env["PYTHONIOENCODING"] = "utf-8"

            if not os.path.exists(CRAWLER_SCRIPT_PATH):
                 logger.critical(f"crawler_script.py not found at {CRAWLER_SCRIPT_PATH}")
                 # This is a fatal error for this operation.
                 # Consider how to propagate this back if not raising an exception.
                 crawl_errors.append(f"Configuration error: crawler_script.py not found for {url_to_crawl}")
                 continue # Skip this URL

            process = subprocess.run(
                [sys.executable, CRAWLER_SCRIPT_PATH, url_to_crawl],
                capture_output=True, text=True, encoding='utf-8',
                check=True, timeout=CRAWLER_TIMEOUT, env=process_env
            )
            raw_md = process.stdout
            markdown_content_single = basic_markdown_clean(raw_md)
            if markdown_content_single:
                # Add a clear separator and source URL before each document's content
                aggregated_markdown_content += f"\n\n## Content source: {url_to_crawl}\n\n{markdown_content_single}\n\n---\n\n"
                logger.info(f"[{kb_name}] Successfully crawled content from {url_to_crawl}. Length: {len(markdown_content_single)}")
                successful_crawls += 1
            else:
                logger.warning(f"[{kb_name}] No content returned after cleaning for {url_to_crawl}")
                crawl_errors.append(f"No content retrieved from {url_to_crawl}")

        except subprocess.CalledProcessError as e:
            error_detail = f"Crawler script failed for {url_to_crawl}. Error: {e.stderr.strip()[:300]}"
            # st.error(error_detail) # UI in chabot_app.py
            logger.error(f"Crawler CalledProcessError for {url_to_crawl}: {e.stderr.strip()}")
            crawl_errors.append(error_detail)
        except subprocess.TimeoutExpired:
            error_detail = f"Crawler script timed out for {url_to_crawl}."
            # st.error(error_detail) # UI in chabot_app.py
            logger.error(f"Crawler TimeoutExpired for {url_to_crawl}")
            crawl_errors.append(error_detail)
        except Exception as e: # Catch other unexpected errors
            error_detail = f"Unexpected error crawling {url_to_crawl}: {e}"
            # st.error(error_detail) # UI in chabot_app.py
            logger.exception(f"Unexpected crawler error for {url_to_crawl}")
            crawl_errors.append(error_detail)
            
        # if overall_progress: overall_progress.progress(int(((i + 1) / len(urls_to_process)) * 90), text=f"Crawled {i+1}/{len(urls_to_process)} URLs")

    if crawl_errors:
        logger.warning(f"[{kb_name}] Encountered {len(crawl_errors)} error(s) during crawling. Successfully crawled {successful_crawls} URLs.")
        # st.warning(...) # UI in chabot_app.py

    if not aggregated_markdown_content:
        logger.error(f"[{kb_name}] No content was aggregated from any of the provided URL(s). Index not created. Crawl errors: {len(crawl_errors)}")
        # st.error(...) # UI in chabot_app.py
        # overall_progress.progress(100, text="No content found or all crawls failed.")
        return False # Indicate failure to create KB

    # If we have some content, proceed to create the index
    logger.info(f"[{kb_name}] Aggregated content length: {len(aggregated_markdown_content)}. Creating vector index from {successful_crawls} sources.")
    # st.info(f"[{kb_name}] Creating vector index...") # UI in chabot_app.py
    
    kb_metadata = {"source_type": "multi_url_collection" if selected_urls else "single_url"}
    if source_base_url and selected_urls:
        kb_metadata["base_url_for_discovery"] = source_base_url
        # Storing all successfully crawled URLs might be too much for metadata,
        # but the content itself has "Content source: URL" headers.
    elif single_url_for_kb:
        kb_metadata["source_url"] = single_url_for_kb

    try:
        created_store = vector_manager.create_new_knowledge_base(
            kb_name,
            aggregated_markdown_content,
            source_metadata=kb_metadata
        )
        # if overall_progress: overall_progress.progress(100, text="Vector index creation complete.")
        if created_store:
            logger.info(f"Knowledge base '{kb_name}' created from {successful_crawls} URL(s)!")
            # st.success(...) # UI in chabot_app.py
            if crawl_errors:
                 logger.info(f"Note: {len(crawl_errors)} URLs had issues during crawling for KB '{kb_name}'.")
            return True
        else:
            logger.error(f"Failed to create vector store for '{kb_name}' (vector_manager returned None).")
            # st.error(...) # UI in chabot_app.py
            return False
    except Exception as e:
        logger.exception(f"Error during vector index creation process for {kb_name}")
        # st.error(...) # UI in chabot_app.py
        return False
    # overall_progress.progress(100, text="KB creation failed.")
    return False # Should be covered by above returns